<?php
 
	session_start();

	$pdo = new PDO('mysql:host=cab230.sef.qut.edu.au;dbname=n9896007', 'n9896007', 'password');

	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	try {
	$result = $pdo->prepare('SELECT * FROM members');
	$result->execute();
	} catch (PDOException $e) {
	echo $e->getMessage();
	}

	//if(isset($_POST['Register']));
		
	
		$First_Name = ($_POST['firstName']);
		
		$Last_Name = ($_POST['lastName']);
		
		$Email = ($_POST['Email']);
		
		$Country = ($_POST['country']);
		
		$Day = ($_POST['day']);
		
		$Month = ($_POST['month']);
		
		$Year = ($_POST['year']);
		
		$Password = ($_POST['password']);
		
		$Confirm_Password = ($_POST['confirmPassword']);

		

		$sql = "INSERT INTO members (First_Name,Last_Name,Email,Country,Day,Month,Year,Password,Confirm_Password)
			VALUES ('$First_Name','$Last_Name','$Email','$Country','$Day','$Month','$Year','$Password','$Confirm_Password')";
			
		header("Location: http://cab230.sef.qut.edu.au/Students/n9896007/index.php");
		
		$result = mysql_query($pdo, $sql);
		
		
		
		$_SESSION['email'] = $email;
		$_SESSION['success'] = "Logged in";

		




?>
